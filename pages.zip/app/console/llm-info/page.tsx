'use client';

export const pageDynamicConfig = 'force-dynamic'; // Force dynamic rendering (renamed)
